import boto3
import json

s3 = boto3.client('s3')

def lambda_handler(event, context):
    text_bucket = event["scanning_text_bucket"]
    scanning_bucket = event["scanning_in_process_bucket"]
    
    # List of buckets to clean up
    s3_buckets = [text_bucket, scanning_bucket]
        
    for bucket in s3_buckets:
        print(f"Processing bucket: {bucket}")
        
        # List all objects in the current bucket
        paginator = s3.get_paginator('list_objects_v2')
        pages = paginator.paginate(Bucket=bucket)

        objects_to_delete = []
        
        for page in pages:
            if 'Contents' in page:
                # Collect all keys (not just folders)
                objects_to_delete.extend(obj['Key'] for obj in page['Contents'])

        # Log keys being deleted
        print(f"Objects to delete from {bucket}: {objects_to_delete}")
        
        # Delete all collected keys
        for key in objects_to_delete:
            s3.delete_object(Bucket=bucket, Key=key)        
    
    return {
        "statusCode": 200,
        "message": "Objects deleted successfully"
    }
